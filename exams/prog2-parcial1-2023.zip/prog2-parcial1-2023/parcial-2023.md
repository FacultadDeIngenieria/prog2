## Primer Parcial Programación 2

### Importante en todos los casos especificar los tipos en las funciones y clases.

### 1. Caesar Cipher

El cifrado César es una técnica de cifrado que utilizó Julio César para enviar mensajes secretos a sus aliados. 
Funciona cambiando las letras del mensaje en un cierto número de posiciones, lo que se conoce como "cambio" o "shift".
Ejemplo: Si se define que el shift es de 2 entonces para la letra A -> el shift dará C.

Se debe implementar un método que dado un `str` y un `int` devuelva el mensaje encriptado de tipo `str` .
Ejemplo:

```python
> encrypt("ABCDEFGHIJKLMNOPQRSTUVWXYZ", 23)
"XYZABCDEFGHIJKLMNOPQRSTUVW"
```

### 2. Implementar los tests para probar estos casos:

```python
encrypt("")
encrypt("AAAAAAAAAAA")
encrypt("ABCXYZ", 23)
```

### 3. Merge de mapas

Hacer el merge de dos mapas de distintos tamaños 

Ejemplo:

```python
d: dict[int, str] = {
    1: "always",
    2: "gonna",
    3: "take",
    4: "me",
    5: "down",
    6: "rick"
}

d1: dict[int, str] = {
    1: "never",
    2: "gonna",
    3: "give",
    4: "you",
    5: "up",
    7: "astley"
}

> merge(d, d1)
{
1: 'neveralways', 2: 'gonnagonna', 3: 'givetake', 
4: 'youme', 5: 'updown', 7: 'astley', 6: 'rick'
}
```

### 4. Sistema de aviones

Crear un sistema de viajes que provea un manejo básico de Pasajeros y Vuelos dada la siguiente definición:

1. Debe soportar una clase `Passenger` con name, lastname y passport (str).
2. Debe soportar una clase `Flight`, que contiene todas estas propiedades.
   1. id: int
   2. from_country: str
   3. to_country: str
   4. price: float
   5. miles: int
   6. capacity: int

Operaciones con ejemplos:

```python
class FlightFullException(Exception):
    """ Flight full exception """
```

```python
pepe_argento = Passenger("pepe", "argento", "AA01")
moni_argento = Passenger("moni", "argento", "AA02")

eze_mia = Flight(1, "EZE", "MIA", 1000, 4420, 1500)
eze_bcn = Flight(2, "EZE", "BCN", 800, 6504, 1000)

# Agrega a los pasajeros a los vuelos 
eze_mia.add_passenger(pepe_argento)
eze_mia.add_passenger(moni_argento)
eze_bcn.add_passenger(moni_argento)

print(Flight.get_flight(1)) 
#prints: Flight from [EZE] to [MIA] with capacity 1500 and costs $1000
print(Flight.get_flight(2)) 
#prints: Flight from [EZE] to [BCN] with capacity 1000 and costs $800

print(pepe_argento) 
#prints: pepe argento spent $1000 in flights and will travel 4420 miles
print(moni_argento) 
#prints: moni argento spent $1800 in flights and will travel 10924 miles
```

* El método `add_passenger` debe tirar (`raise`) la excepción `FlightFullException` si el vuelo esta lleno.
* Passenger deberá tener 2 métodos:
  * cost -> devuelve el costo total de todos los vuelos de una persona
  * miles -> devuelve la cantidad total de millas de todos los vuelos de una persona
* Los objetos Passenger y Flight **NO podrán** tener más estado de lo definido previamente. 
