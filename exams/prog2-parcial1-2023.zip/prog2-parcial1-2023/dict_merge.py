m: dict[int, str] = {
    1: "always",
    2: "gonna",
    3: "take",
    4: "me",
    5: "down",
    6: "rick"
}

m1: dict[int, str] = {
    1: "never",
    2: "gonna",
    3: "give",
    4: "you",
    5: "up",
    7: "astley"
}


def merge(m: dict[int, str], m1: dict[int, str]):
    return aux_merge(m, m1) if len(m) >= len(m1) else aux_merge(m1, m)


def aux_merge(m: dict[int, str], answer: dict[int, str]):
    for (key, value) in m.items():
        if key in answer.keys():
            answer[key] = answer[key] + value
        else:
            answer[key] = value
    return answer

print(merge(m, m1))