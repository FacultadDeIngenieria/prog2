from __future__ import annotations

from typing import Dict, List, Set


class FlightFullException(Exception):
    """ Flight full exception """


class Flight:
    flights: Dict[int, Flight] = {}
    id: int
    from_country: str
    to_country: str
    price: float
    capacity: int
    passangers: Set[Passenger]
    miles: int

    def __init__(self, id: int, from_country: str, to_country: str, price: float, miles: int, capacity: int):
        self.id = id
        self.from_country = from_country
        self.to_country = to_country
        self.price = price
        self.miles = miles
        self.capacity = capacity
        self.passangers = set()
        Flight.flights[id] = self

    @staticmethod
    def get_flight(id: int) -> Flight:
        return Flight.flights[id]

    def add_passenger(self, passenger: Passenger):
        if len(self.passangers) < self.capacity:
            self.passangers.add(passenger)
        else:
            raise FlightFullException()

    def __str__(self):
        return f"Flight from [{self.from_country}] to [{self.to_country}] with capacity {self.capacity} and costs ${self.price}"


class Passenger:
    name: str
    lastname: str
    passport: str

    def __init__(self, name: str, lastname: str, passport: str):
        self.name = name
        self.lastname = lastname
        self.passport = passport

    def cost(self) -> float:
        cost = 0
        for (key, flight) in Flight.flights.items():
            if self in flight.passangers:
                cost += flight.price
        return cost

    def miles(self) -> int:
        miles = 0
        for (key, flight) in Flight.flights.items():
            if self in flight.passangers:
                miles += flight.miles
        return miles

    def __str__(self):
        return f"{self.name} {self.lastname} spent ${self.cost()} in flights and will travel {self.miles()} miles"


pepe_argento = Passenger("pepe", "argento", "AA01")
moni_argento = Passenger("moni", "argento", "AA02")

eze_mia = Flight(1,"EZE", "MIA", 1000, 4420, 1500)
eze_bcn = Flight(2,"EZE", "BCN", 800, 6504, 1000)

eze_mia.add_passenger(pepe_argento)
eze_mia.add_passenger(moni_argento)
eze_bcn.add_passenger(moni_argento)

print(Flight.get_flight(1))
print(Flight.get_flight(2))

print(pepe_argento)
print(moni_argento)

