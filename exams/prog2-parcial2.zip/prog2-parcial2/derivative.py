from typing import List, Tuple, Callable


def derivative(
        f: Callable[[float], float],  # function
        x0: float,  # from
        xn: float,  # to
        n: int,  # number of points
        h: float  # interval
) -> List[Tuple[float, float, float]]:

    def d(x):
        return (f(x + h) - f(x)) / h
    interval = (xn - x0) / n

    return [(xi, f(xi), d(xi + h)) for xi in [x0 + interval * i for i in range(0, n)]]
