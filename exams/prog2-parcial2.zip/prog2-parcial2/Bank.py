from abc import ABC, abstractmethod


class Bank:

    def __init__(self, name: str):
        self.name = name
        self.accounts = []

    def calculate_interest(self, interest: float):
        for account in self.accounts:
            account.calculate_interest(interest)


class NotEnoughMoneyException(Exception):
    def __init__(self):
        super().__init__("No posees dinero suficiente para realizar esta operación")


class Account(ABC):

    def __init__(self, bank: Bank, name: str):
        self.name = name
        self.balance = 0
        self.bank = bank
        bank.accounts.append(self)

    def deposit(self, amount: float):
        self.balance += amount

    @abstractmethod
    def withdraw(self, amount: float):
        pass

    def get_balance(self):
        return self.balance

    def calculate_interest(self, interest: float):
        pass


class CurrentAccount(Account):
    def __init__(self, bank: Bank, name: str, overdraft: float):
        super().__init__(bank, name)
        self.overdraft = overdraft

    def withdraw(self, amount: float):
        if amount <= self.balance + self.overdraft:
            self.balance -= amount
        else :
            print(NotEnoughMoneyException())


class SavingAccount(Account):

    def withdraw(self, amount: float):
        if amount <= self.balance:
            self.balance -= amount
        else:
            print(NotEnoughMoneyException())

    def calculate_interest(self, interest: float):
        self.balance = self.balance * ( 1 + interest)


citi = Bank("Citibank")
cuenta_joe = CurrentAccount(citi, "Joe", 1000) # 1000 de descubierto permitido
cuenta_maria = SavingAccount(citi, "Maria")

cuenta_joe.deposit(500)
cuenta_joe.withdraw(800)
print(cuenta_joe.get_balance()) # Imprime -300
cuenta_joe.withdraw(2000)       # Da una excepción
cuenta_joe.deposit(1000)

cuenta_maria.deposit(1000)

citi.calculate_interest(0.05) # Sumar 5% de interés a las cuentas que corresponda

print(cuenta_joe.get_balance())    # Imprime 700
print(cuenta_maria.get_balance())  # Imprime 1050
