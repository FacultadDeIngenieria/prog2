from typing import Callable, Tuple


def derivative(f : Callable, x0: float, xn: float, n : float, h: float):
    derivates: list[tuple[float, float, float]] = []
    xi = x0
    interval = (xn - x0) / n
    while xi < xn:
        derivates.append((xi, f(xi), derivative_function(f,xi, h)))
        xi += interval

    return derivates


def derivative_function(f: Callable[[float],float], xi: float, h: float):
    return (f(xi + h) - f(xi)) / h

print(derivative(lambda x: x * x, 0, 10, 5, 0.001))

