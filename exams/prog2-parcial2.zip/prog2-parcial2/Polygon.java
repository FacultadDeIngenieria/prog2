package org.prog2;

import java.util.ArrayList;
import java.util.List;

class Point {
    double x, y;

    public Point(double x, double y) {
        this.x = x;
        this.y = y;
    }

}

class Polygon {
    List<Point> points;

    public Polygon(List<Point> points) {
        this.points = points;
    }

    double area() {
        double area = 0;
        int size = points.size();
        if (size < 3) {
            System.out.println("Pone bien...");
            return 0;
        } else {
            int trianglesAmount = size - 2;
            Point p0 = points.get(0);
            for(int i = 0; i < trianglesAmount; i += 1 ){
                Point p1 = points.get(i+1);
                Point p2 = points.get(i+2);
                double d1 = distance(p0, p1);
                double d2 = distance(p1, p2);
                double d3 = distance(p0, p2);

                double heron = heron(d1, d2, d3);
                area += heron;
            }

            return area;
        }
    }

    double distance(Point a, Point b) {
        return Math.sqrt(Math.pow(b.x - a.x, 2) + Math.pow(b.y - a.y, 2));
    }

    double heron(double a, double b, double c) {
        double s = (a + b + c) / 2;
        double quotient = s * (s - a) * (s - b) * (s - c);
        return Math.sqrt(quotient);
    }

    public static void main(String[] args) {
        ArrayList<Point> list = new ArrayList<Point>();
        list.add(new Point(0.0, 0.0));
        list.add(new Point(0.0, 2.0));
        list.add(new Point(2.0, 2.0));
        list.add(new Point(2.0, 0.0));
        Polygon p = new Polygon(list);
        System.out.println(p.area());
    }
}

