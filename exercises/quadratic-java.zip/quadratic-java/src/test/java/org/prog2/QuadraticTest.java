package org.prog2;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class QuadraticTest {
    private static final Quadratic q = new Quadratic(-2, 1, 2);

    @Test
    public void testToString() {
        assertEquals("-2.0x^2 + 1.0x + 2.0", q.toString());
    }
    @Test
    public void testDerivative() {
        assertEquals("-4.0x + 1.0", q.derivative());
    }
    @Test
    public void testRoots() {
        double[] result = {3.0, 2.0};
        Quadratic q = new Quadratic(1, -5, 6);
        assertArrayEquals(result, q.roots());
    }

    @Test
    public void testEvaluate() {
        assertEquals(-4.0, q.evaluate(2.0));
    }
}
