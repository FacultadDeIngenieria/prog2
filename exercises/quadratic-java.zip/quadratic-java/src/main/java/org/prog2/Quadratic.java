package org.prog2;

public class Quadratic {
    private final double a;
    private final double b;
    private final double c;

    public Quadratic(double a, double b, double c) {
    //         Implement
    }

    public double evaluate(double x) {
    //         Implement
    }

    @Override
    public String toString() {
    //         Implement
    }

    public String derivative() {
    //         Implement
    }

    public double[] roots() {
    //         Implement
    }
}
