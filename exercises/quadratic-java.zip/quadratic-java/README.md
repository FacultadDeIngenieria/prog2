# Quadratic Equation

## Instructions

You have to solve a Second grade equation of the form **ax<sup>2</sup> + bx + c**.

### 1. Implement a class with 3 double attributes `a`, `b` and `c`

### 2. Implement the `toString` method, to convert the Equation to an `String`

Some examples:

```java
> var q = new Quadratic(-2, 1, 2);
> q
-2.0x^2 + 1.0x + 2.0
```

### 3 Implement `evaluate` that returns the value of the function at a given value `x`

```java
> var q = new Quadratic(-2, 1, 2);
> q.evaluate(2.0)
-4.0
```

### 3. Implement the `roots` method that returns the solutions (x<sub>1</sub> and x<sub>2</sub>) as an `array` of double.

The root function is defined as:

```java
public double[] roots()
```
If there are not real solutions the function returns an empty array

## Examples

`new Quadratic(2, 0, 0).roots()` should return `[0.0]`

`new Quadratic(1, 2, 1).roots()` should return `[-1, -1]`

`new Quadratic(1, 1, 1).roots()` should return `[]`

`new Quadratic(1, 1, 1).evaluate(1)` should return `3.0`

`Quadratic(1, 2, 3).derivative()` should return `2 * x + 2`
